<?php

//membuat koneksi ke databases dengan file koneksi.php
include 'koneksi.php';

//menangkap nilai variabel yang di kirim oleh file login.php
$username=$_POST['username'];
$password=$_POST['password'];

//membuat seleksi dengan data bases

$baris=mysqli_query($koneksi,"SELECT * FROM tbl_user where username='$username' and password='$password' ");

//ambil data untuk di samakan

$ambil=mysqli_fetch_array($baris);

//kita seleksi antara varibel yang di kirim oleh file login.php dengan databases

if ($ambil['username']==$username and $ambil['password']==$password ) {
    
    //MEMBUAT AGAR BILA BERHASIL KITA AKAN BERADA DI INDEX.PHP 
    session_start();
$_SESSION['username']=$ambil['username'];
$_SESSION['password']=$ambil['password'];

    header('location:index.php');


}else{

header('location:index.php');
}


?>