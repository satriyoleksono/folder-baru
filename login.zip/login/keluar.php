<?php
//untuk menghapus session
session_start(); //sesion masih ada 
session_destroy();//menghapus semua sesion

//membuat user ke menu index

header('location:index.php');


?>