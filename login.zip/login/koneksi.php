<?php
//membuat koneksi ke databases 

$koneksi=mysqli_connect('localhost','root','','login' );



?>