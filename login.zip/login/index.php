<?php

//membuat agar user tidak bisa langsung masuk ke index
//kita beri session

session_start();

if (empty($_SESSION['username'])) {
    echo 'anda harus login dlu <a href="login.php">klik disini</a> ';
}else{
    


    echo 'selamat datang';
    echo 'keluar <a href="keluar.php">keluar</a> ';
}

//maaf kebalik



?>